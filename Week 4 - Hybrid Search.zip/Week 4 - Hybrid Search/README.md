# Hybrid Search Benchmark for a Mid-Sized Fashion Label

## Project Overview

This Week 4 project builds a retrieval benchmark for a fictional mid-sized fashion label.

The benchmark compares three retrieval methods:

- BM25 keyword retrieval
- Dense embedding retrieval using sentence-transformers
- Hybrid retrieval using weighted Reciprocal Rank Fusion and cross-encoder re-ranking

## Dataset

The project uses 1,800 synthetic fashion catalogue paragraphs and 40 handwritten retrieval questions. Each question has a marked correct source paragraph.

The data contains no private customer or confidential company information.

## Evaluation

The 40 questions are divided into:

- 28 tuning questions
- 12 unseen final questions

The fusion weight is selected using the tuning questions only. Final performance is then measured once on the 12 unseen questions.

The final benchmark reports:

- Recall@1
- Recall@3
- Recall@5
- MRR

## Tools

- Python
- Jupyter Notebook
- rank_bm25
- sentence-transformers
- pandas
- numpy
- matplotlib

## Files

- Hybrid_Search_Benchmark.ipynb
- data/fashion_corpus.csv
- data/questions.csv
- data/tuning_questions.csv
- data/final_questions.csv
- data/data_sheet.csv
- results/benchmark_results.csv
- results/benchmark_chart.png
- results/failing_questions.csv
- requirements.txt
- CHANGELOG.md

## Validation

The final questions are kept separate from the tuning questions. The hybrid pipeline combines the top 20 BM25 and dense candidates with weighted Reciprocal Rank Fusion and applies the cross-encoder to the top 20 candidates.

Three real failing-question examples are saved in the results folder.

## Limitation

The corpus is synthetic, so it may not represent the full variety and ambiguity of a real fashion company's data.

## Improvement

With more time, the benchmark could be tested on a larger public fashion dataset with more varied natural-language questions.
