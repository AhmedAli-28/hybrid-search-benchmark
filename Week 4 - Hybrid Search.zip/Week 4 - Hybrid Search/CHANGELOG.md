# Changelog

## Week 4

- Created a synthetic fashion corpus with 1,800 paragraphs.
- Created 40 handwritten retrieval questions with source paragraph IDs.
- Added a privacy and data sheet.
- Implemented BM25 retrieval.
- Implemented dense retrieval using sentence-transformers.
- Implemented weighted Reciprocal Rank Fusion.
- Added cross-encoder re-ranking of the top 20 candidates.
- Added one common retrieval function for all three methods.
- Tuned the fusion weight using only the 28 tuning questions.
- Evaluated the final system on 12 unseen questions.
- Calculated Recall@1, Recall@3, Recall@5 and MRR.
- Added benchmark chart and failing-question evidence.
- Documented validation, problems found and fixes.
